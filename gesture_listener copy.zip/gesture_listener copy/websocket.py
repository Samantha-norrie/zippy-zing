import asyncio
import json
import websockets

import numpy as np
import shutil
import tensorflow as tf
from sklearn.metrics import classification_report
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential
import pathlib
import sys
import os
np.set_printoptions(threshold=sys.maxsize)
data_dir = pathlib.Path("CurrentGesture")
IMAGE_WIDTH = 185
IMAGE_HEIGHT = 105
BATCH_SIZE = 32

def predictGesture():
    model = keras.models.load_model("my_model")
    number_of_files = len(os.listdir('CurrentGesture/gesture'))
    print(number_of_files)
    test_steps_per_epoch = np.math.ceil(number_of_files / BATCH_SIZE)
    curr_gesture = tf.keras.utils.image_dataset_from_directory(
        'CurrentGesture',
        seed=None,
        shuffle=False,
        image_size=(IMAGE_HEIGHT, IMAGE_WIDTH),
        batch_size=BATCH_SIZE)
    predictions = model.predict_generator(curr_gesture, test_steps_per_epoch)
    predicted_classes = np.argmax(predictions, axis=1)
    print("predicted class", )
    print(np.bincount(predicted_classes).argmax())
    return np.bincount(predicted_classes).argmax()

async def handler(websocket):
    # while True:
    #     message = await websocket.recv()
    #     print(message)
    print("the websocket", websocket)
    gesture_prediction = int(predictGesture())
    gesture = {"gesture": gesture_prediction}
    await websocket.send(json.dumps(gesture))

async def main():
    async with websockets.serve(handler, "", 8001):
        await asyncio.Future()  # run forever


if __name__ == "__main__":
    asyncio.run(main())
