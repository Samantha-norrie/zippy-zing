import argparse
import sys
import json
import os
sys.path.append('sensel-lib-wrappers/sensel-lib-python')
import sensel
import PIL
from PIL import Image
import cv2
import numpy
from numpy import asarray
import matplotlib.pyplot as plt
import numpy as np
import shutil
import tensorflow as tf
from sklearn.metrics import classification_report
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential
import pathlib
numpy.set_printoptions(threshold=sys.maxsize)

data_dir = pathlib.Path("CurrGesture")
IMAGE_WIDTH = 185
IMAGE_HEIGHT = 105
BATCH_SIZE = 32

def openSensel():
    handle = None
    (error, device_list) = sensel.getDeviceList()
    if device_list.num_devices != 0:
        (error, handle) = sensel.openDeviceByID(device_list.devices[0].idx)
    return handle

def initFrame(handle):
    error = sensel.setFrameContent(handle, sensel.FRAME_CONTENT_PRESSURE_MASK)
    (error, frame) = sensel.allocateFrameData(handle)
    error = sensel.startScanning(handle)
    return frame
def closeSensel(handle, frame):
    error = sensel.freeFrameData(handle, frame)
    error = sensel.stopScanning(handle)
    error = sensel.close(handle)

def scanFrameHelper(handle, frame, info):
    error = sensel.readSensor(handle)
    error = sensel.getFrame(handle, frame)

    #Create nested array of force data
    new_frame_scan_array = []
    row= []
    for n in range(info.num_rows*info.num_cols):
        if n %info.num_cols-1 == 0:
            new_frame_scan_array.append(row.copy())
            row = []
        force = frame.force_array[n]
        row.append(force)

    force_found = False
    
    image_gray_scale = PIL.Image.new(mode="L", size=(info.num_cols, info.num_rows))
    image_gray_scale_amplified_force = PIL.Image.new(mode="L", size=(info.num_cols, info.num_rows))
    for j in range(0, len(new_frame_scan_array)):
        for k in range(0, len(new_frame_scan_array[j])):
            force_val = int(new_frame_scan_array[j][k])
            if force_val >0:
                if force_val >=10:
                    force_found = True
                image_gray_scale.putpixel((k, j), (128+force_val))
                image_gray_scale_amplified_force.putpixel((k, j), (128+2*force_val))
            else:
                image_gray_scale.putpixel((k, j), (128))
                image_gray_scale_amplified_force.putpixel((k, j), (128))

    return (force_found, (image_gray_scale, image_gray_scale_amplified_force))

def scanForceFrames(handle, frame, info):
    finished_recording = False
    force_detected = False
    frame_images = []
    try:
        while not finished_recording:

            # Scan frame
            (current_frame_force_status, (frame_image, frame_image_force_amplified)) = scanFrameHelper(handle, frame, info)

            # First force frame detected
            if not force_detected and current_frame_force_status:
                force_detected = True
                frame_images.append((frame_image, frame_image_force_amplified))

            # detection of subsequent force frames
            elif current_frame_force_status:
                frame_images.append((frame_image, frame_image_force_amplified))
            
            # terminate recording when force is no longer detected
            elif force_detected and not current_frame_force_status:
                finished_recording = True
    except:
        return []
    return frame_images

def createAndSavePreprocessedImages(raw_gesture_images):
    for i in range(0, len(raw_gesture_images)):
            if i != 0:
                image_gray_scale = PIL.Image.new(mode="L", size=(185, 105))
                image_gray_scale = cv2.add(asarray(image_gray_scale), asarray(raw_gesture_images[i][1]))
                image_gray_scale_arr = asarray(image_gray_scale)
                prev_image_gray_scale_arr = asarray(raw_gesture_images[i-1][0])
                for j in range(0, 105):
                    for k in range(0, 185):
                        image_gray_scale_arr[j][k] = image_gray_scale_arr[j][k]-(prev_image_gray_scale_arr[j][k]-128)
                Image.fromarray(image_gray_scale).save("CurrentGesture/gesture/" + str(i) + ".jpeg")

def predictGesture():
    model = keras.models.load_model("my_model")
    number_of_files = len(os.listdir('CurrGesture/gesture'))
    print(number_of_files)
    test_steps_per_epoch = np.math.ceil(number_of_files / BATCH_SIZE)
    curr_gesture = tf.keras.utils.image_dataset_from_directory(
        'CurrGesture',
        seed=None,
        shuffle=False,
        image_size=(IMAGE_HEIGHT, IMAGE_WIDTH),
        batch_size=BATCH_SIZE)
    predictions = model.predict_generator(curr_gesture, test_steps_per_epoch)
    predicted_classes = np.argmax(predictions, axis=1)
    print("predicted classes", np.bincount(predicted_classes).argmax())
    return np.bincount(predicted_classes).argmax()

def setUpStorageDirectory():
        if not os.path.exists("CurrentGesture"):
            os.mkdir("CurrentGesture")
            preprocessed_images_path = os.path.join("CurrentGesture/", "gesture")
            os.mkdir(preprocessed_images_path)
        elif not os.path.exists("CurrentGesture/gesture"):
            preprocessed_images_path = os.path.join("./", "gesture")
            os.mkdir(preprocessed_images_path)
        else:
            shutil.rmtree('CurrentGesture/gesture')

def listenForGestures():
    print("open sensel")
    handle = openSensel()
    print("init frame")
    frame = initFrame(handle)

    (error, info) = sensel.getSensorInfo(handle)
    try:
        while True:
            setUpStorageDirectory()
            raw_gesture_images = scanForceFrames(handle, frame, info)
            createAndSavePreprocessedImages(raw_gesture_images)
            predicted_gesture = predictGesture()
            print("predicted gesture", predicted_gesture)
    except:
        closeSensel(handle, frame)
listenForGestures()
